const ClientSearch={
filter(clients,q){
q=(q||'').toLowerCase();
return clients.filter(c=>
(c.name||'').toLowerCase().includes(q)||
(c.ic||'').toLowerCase().includes(q)||
(c.phone||'').toLowerCase().includes(q));
}
};