const ClientProfile={
open(id){
location.href='client.html?view=profile&id='+id;
}
};