class SignaturePad{
constructor(canvasId){
this.canvas=typeof canvasId==="string"?document.getElementById(canvasId):canvasId;
this.ctx=this.canvas.getContext("2d");
this.resize();
this.isDirty=false;
this.bind();
window.addEventListener("resize",()=>this.resize());
}
resize(){
const data=this.isDirty?this.toDataURL():null;
this.canvas.width=this.canvas.offsetWidth;
this.canvas.height=180;
this.ctx.lineWidth=2;
this.ctx.lineCap="round";
if(data)this.load(data);
}
point(e){
const r=this.canvas.getBoundingClientRect();
const t=e.touches?e.touches[0]:e;
return{x:t.clientX-r.left,y:t.clientY-r.top};
}
bind(){
const start=e=>{
this.drawing=true;
const p=this.point(e);
this.ctx.beginPath();
this.ctx.moveTo(p.x,p.y);
e.preventDefault();
};
const move=e=>{
if(!this.drawing)return;
const p=this.point(e);
this.ctx.lineTo(p.x,p.y);
this.ctx.stroke();
this.isDirty=true;
e.preventDefault();
};
const end=()=>this.drawing=false;
["mousedown","touchstart"].forEach(v=>this.canvas.addEventListener(v,start,{passive:false}));
["mousemove","touchmove"].forEach(v=>this.canvas.addEventListener(v,move,{passive:false}));
["mouseup","mouseleave","touchend","touchcancel"].forEach(v=>this.canvas.addEventListener(v,end));
}
clear(){
this.ctx.clearRect(0,0,this.canvas.width,this.canvas.height);
this.isDirty=false;
}
load(dataUrl){
if(!dataUrl)return;
const img=new Image();
img.onload=()=>{
this.ctx.clearRect(0,0,this.canvas.width,this.canvas.height);
this.ctx.drawImage(img,0,0,this.canvas.width,this.canvas.height);
this.isDirty=true;
};
img.src=dataUrl;
}
toDataURL(){return this.canvas.toDataURL("image/png");}
}
window.createSignaturePad=id=>new SignaturePad(id);
