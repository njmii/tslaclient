const STORAGE_KEY = "tsla_clients";

function getClients() {

    const data = localStorage.getItem(STORAGE_KEY);

    return data ? JSON.parse(data) : [];

}

function getClient(id) {

    return getClients().find(client => client.id === id) || null;

}

function saveClient(client) {

    const clients = getClients();

    // New client
    if (!client.id) {

        client.id = "client_" + Date.now();

        client.createdAt = new Date().toISOString();

        clients.push(client);

    }

    // Existing client
    else {

        const index = clients.findIndex(item => item.id === client.id);

        if (index >= 0) {

            clients[index] = {

                ...clients[index],

                ...client

            };

        } else {

            clients.push(client);

        }

    }

    client.updatedAt = new Date().toISOString();

    localStorage.setItem(

        STORAGE_KEY,

        JSON.stringify(clients)

    );

    return client.id;

}

function updateClient(id, updatedClient) {

    const client = getClient(id);

    if (!client) return false;

    saveClient({

        ...client,

        ...updatedClient,

        id

    });

    return true;

}

function deleteClient(id) {

    const clients = getClients().filter(client => {

        return client.id !== id;

    });

    localStorage.setItem(

        STORAGE_KEY,

        JSON.stringify(clients)

    );

}

function clearClients() {

    localStorage.removeItem(STORAGE_KEY);

}